<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🎬 Movie Tracker</title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="<?php echo e(url('resources/css/style.css')); ?>">
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script>$.ajaxSetup({headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')}});
    </script>
    <script defer src="<?php echo e(url('resources/js/API_Ops.js')); ?>"></script>
    <script defer src="<?php echo e(url('resources/js/DB_Ops.js')); ?>"></script>
</head>

<body>
    <?php echo $__env->make('partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    <?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</body>
</html><?php /**PATH D:\xampp\htdocs\Web-2\A2\laravel\resources\views/layouts/app.blade.php ENDPATH**/ ?>